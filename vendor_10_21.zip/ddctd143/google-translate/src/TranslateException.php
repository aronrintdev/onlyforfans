<?php namespace Dedicated\GoogleTranslate;

use Exception;

class TranslateException extends Exception
{
    //
}
